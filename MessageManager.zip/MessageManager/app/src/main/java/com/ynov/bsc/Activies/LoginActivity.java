package com.ynov.bsc.Activies;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import com.example.brice.messagemanager.R;
import com.ynov.bsc.Services.AsyncResponce;
import com.ynov.bsc.Services.Authentification;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class LoginActivity extends AppCompatActivity {
    TextView login;
    TextView password;
    CheckBox rememberme;
    Button empty;
    Button validate;
    SharedPreferences prefs;
    SharedPreferences.Editor prefEditor;

    @Override
    protected void onResume() {
        super.onResume();
        validate.setEnabled(true);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Recuperation de tout les inputs
        login = findViewById(R.id.input_username);
        password = findViewById(R.id.input_password);
        rememberme = findViewById(R.id.input_rememberme);
        empty = findViewById(R.id.btn_empty);
        validate = findViewById(R.id.btn_validate);

        // Mise en place du listener
        validate.setOnClickListener(genericOnClickListener);
        empty.setOnClickListener(genericOnClickListener);
        rememberme.setOnClickListener(genericOnClickListener);

        // Instanciation des preferences et de sont editeur
        prefs = PreferenceManager.getDefaultSharedPreferences(LoginActivity.this);
        prefEditor = prefs.edit();

        // Si on a déja enregistrer le login et le password avant , on le mets automatiquement dans les champs
        if(prefs.getString("login", null) != null && prefs.getString("password", null) != null){
            login.setText(prefs.getString("login", null));
            password.setText(prefs.getString("password", null));
            rememberme.setChecked(true);
        }
    }

    View.OnClickListener genericOnClickListener = new View.OnClickListener(){
        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.btn_validate:
                    validate.setEnabled(false);
                    if(TextUtils.isEmpty(login.getText())){
                        login.setError("login obligatoire");
                    }

                    if(TextUtils.isEmpty(password.getText())){
                        password.setError("password obligatoire");
                    }
                    if(TextUtils.isEmpty(login.getText()) && TextUtils.isEmpty(password.getText())) {
                        validate.setEnabled(true);
                    }
                    if(!TextUtils.isEmpty(login.getText()) && !TextUtils.isEmpty(password.getText())) {
                        new Authentification(new AsyncResponce() {
                            @Override
                            public void ComputeResult(Object result) {
                                String res = (String) result;
                                if(res.equals("true")){
                                    Toast.makeText(LoginActivity.this, "Connected", Toast.LENGTH_LONG).show();

                                    if(rememberme.isChecked()){
                                        // Si on doit se souvenir du login et du mot de passe on l'enregistre
                                        prefEditor.putString("login", login.getText().toString())
                                                .putString("password", password.getText().toString())
                                                .apply();
                                    }
                                    else{
                                        // Sinon on le supprime
                                        prefEditor.remove("login")
                                                .remove("password").apply();
                                    }
                                    //Et on redirige vers le Menu
                                    Intent intent = new Intent(LoginActivity.this, MenuActivity.class);
                                    startActivity(intent);

                                }else{
                                    login.setError("Login ou Mot de passe incorrect");

                                }
                            }
                        }).execute(login.getText().toString(), password.getText().toString());
                    }


                    break;
                case R.id.btn_empty:
                    //On vide les champs
                    login.setText(null);
                    password.setText(null);
                    validate.setEnabled(true);

                    break;
                case R.id.input_rememberme:
                    // Si on uncheck rememberme, on supprime les SharedPreferences.
                    validate.setEnabled(true);

                    if(!rememberme.isChecked()){
                        prefEditor.remove("login")
                                .remove("password").apply();
                    }
                default:
                    break;
            }
        }
    };


}
