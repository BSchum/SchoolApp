package com.ynov.bsc.Activies;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.brice.messagemanager.R;
import com.ynov.bsc.Services.ImageService;

public class DetailledActivity extends AppCompatActivity {

    TextView name;
    TextView description;
    TextView sexe;
    TextView espece;
    ImageView iv;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detailled);

        //Recuperation des views
        name = findViewById(R.id.det_name);
        description = findViewById(R.id.det_desc);
        sexe = findViewById(R.id.det_sexe);
        espece = findViewById(R.id.det_espece);
        iv = findViewById(R.id.image);
        //Recupération des données passés via l'intent
        Intent intent = getIntent();
        name.setText(intent.getStringExtra("name"));
        description.setText(intent.getStringExtra("description"));
        sexe.setText(intent.getStringExtra("sexe"));
        espece.setText(intent.getStringExtra("espece"));
        //Recuperation de l'id via l'intent afin de recuperer l'image via celui ci
        int imageId = intent.getIntExtra("id",1);

        ImageService im = new ImageService(iv);
        im.execute(Integer.toString(imageId));

    }


}
