package com.ynov.bsc.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.brice.messagemanager.R;
import com.ynov.bsc.Model.Entrée;

import java.util.List;

/**
 * Created by Brice on 26/03/2018.
 */

public class EntréeAdapter extends BaseAdapter{
    private List<Entrée> entryList;
    private Context context;
    private LayoutInflater ly;

    public EntréeAdapter(Context context, List<Entrée> entryList) {
        this.context = context;
        this.entryList = entryList;
        this.ly = LayoutInflater.from(context);
    }
    @Override
    public int getCount() {
        return entryList.size();
    }

    @Override
    public Object getItem(int position) {
        return entryList.get(position);
    }

    @Override
    public long getItemId(int position) {
        if(entryList.get(position) !=  null){
            return position;
        }
        else{
            return -1;
        }
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        RelativeLayout layoutItem;
        //J'utilise mon layout ou le layout passé.
        if (convertView == null) {
            //Initialisation de notre item à partir du  layout entry_item
            layoutItem = (RelativeLayout) ly.inflate(R.layout.entry_item, parent, false);
        } else {
            layoutItem = (RelativeLayout) convertView;
        }
        // Je recupere toutes mes views
        TextView entryName = (TextView)layoutItem.findViewById(R.id.det_name);
        TextView entryGender = (TextView)layoutItem.findViewById(R.id.det_sexe);
        TextView entryEspece = (TextView)layoutItem.findViewById(R.id.det_espece);


        // Je set les texts de toutes les texts view du layout.
        entryName.setText(entryList.get(position).getNom());
        entryGender.setText(entryList.get(position).getSexe());
        entryEspece.setText(entryList.get(position).getEspece());
        //On renvoie le layout avec les nouveaux objets.
        return layoutItem;
    }
}
