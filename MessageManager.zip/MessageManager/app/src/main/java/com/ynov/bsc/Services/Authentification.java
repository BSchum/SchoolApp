package com.ynov.bsc.Services;

import android.os.AsyncTask;
import android.util.Log;

import com.ynov.bsc.Services.AsyncResponce;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class Authentification extends AsyncTask<String, String, String> {
    AsyncResponce delegate;
    public Authentification(AsyncResponce delegate){
        this.delegate = delegate;
    }
    @Override
    protected String doInBackground(String...strings){
        URL url = null;
        HttpURLConnection urlConnection = null;
        String response = "";

        // Requete vers le web service
        try {
            url = new URL("http://thibault01.com:8081/authorization?login=" + strings[0]
                    + "&mdp="
                    + strings[1]);
            urlConnection = (HttpURLConnection) url.openConnection();
            InputStream in = urlConnection.getInputStream();
            StringBuilder sb = new StringBuilder();
            BufferedReader reader = new BufferedReader(new InputStreamReader(in));
            while((response = reader.readLine()) != null){
                sb.append(response);
            }
            response = sb.toString();
        }catch(Exception e){
            Log.e("Error", "Erreur de l'acces au WS", e);
        }

        //On envoie a OnProgressUpdate la réponse de la requete
        publishProgress(response);
        return response;
    }

    @Override
    protected void onProgressUpdate(String...values){
        super.onProgressUpdate(values);
        delegate.ComputeResult(values[0]);
    }
}
