package com.ynov.bsc.Activies;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import com.example.brice.messagemanager.R;
import com.ynov.bsc.Adapter.EntréeAdapter;
import com.ynov.bsc.Model.Entrée;
import com.ynov.bsc.Services.AsyncResponce;
import com.ynov.bsc.Services.GetEntrys;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class ListEntryActivity extends AppCompatActivity {
    ListView entrys;
    List<Entrée> entryList;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_entry);

        entrys = findViewById(R.id.entry_list);
        entryList = new ArrayList<Entrée>();
        //EntryList est une liste d'entrée que l'on va recuperer
        new GetEntrys(new AsyncResponce() {
            @Override
            public void ComputeResult(Object result) {
                String dataS = (String) result;
                try{
                    JSONArray datas = new JSONArray(dataS);
                    //Pour chaque entrée dans le json, je rempli ma liste
                    for(int i=0; i< datas.length(); i++){
                        JSONObject entry = datas.getJSONObject(i);
                        entryList.add(new Entrée(entry.getString("nom"),
                                entry.getString("sexe"),
                                entry.getString("description"),
                                entry.getString("espece"),
                                entry.getInt("id")));
                    }
                    //Je creer mon adapter qui va utiliser un modele pour mes données, et l'envoyer a la list view
                    EntréeAdapter adapter = new EntréeAdapter(ListEntryActivity.this, entryList);

                    entrys.setAdapter(adapter);
                }catch (Exception e){
                    Log.e("Error", "JSON Exception", e);
                }
            }
        }).execute();
        //Recuperation des entrées
        entrys.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                //Passage des données de l'entré a la vue détaillé.
                Intent intent = new Intent(ListEntryActivity.this, DetailledActivity.class);
                intent.putExtra("name", entryList.get(position).getNom());
                intent.putExtra("description", entryList.get(position).getDescription());
                intent.putExtra("sexe", entryList.get(position).getSexe());
                intent.putExtra("espece", entryList.get(position).getEspece());
                intent.putExtra("id", entryList.get(position).getId());
                startActivity(intent);
            }
        });
    }


}

