package com.ynov.bsc.Activies;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.brice.messagemanager.R;
import com.ynov.bsc.Services.AddEntryService;
import com.ynov.bsc.Services.AsyncResponce;

import org.json.JSONObject;

import java.io.DataOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class AddEntryActivity extends AppCompatActivity {
    TextView input_name;
    TextView input_sexe;
    TextView input_espece;
    TextView input_desc;

    Button add;
    Button reset;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_entry);
        // Mes textviews
        input_name = findViewById(R.id.name_input);
        input_sexe = findViewById(R.id.sexe_input);
        input_espece = findViewById(R.id.espece_input);
        input_desc = findViewById(R.id.desc_input);
        // Mes boutons
        add = findViewById(R.id.add_btn_entry);
        reset = findViewById(R.id.reset_btn_entry);
        // Mes events
        add.setOnClickListener(genericOnClickListener);
        reset.setOnClickListener(genericOnClickListener);
    }

    View.OnClickListener genericOnClickListener = new View.OnClickListener(){
        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.add_btn_entry:
                    //Traitement des inputs ( vide ou non ) etc...
                    if(TextUtils.isEmpty(input_name.getText())){
                        input_name.setError("Nom obligatoire");
                    }

                    if(TextUtils.isEmpty(input_sexe.getText())){
                        input_sexe.setError("Sexe obligatoire");
                    }

                    if(TextUtils.isEmpty(input_espece.getText())){
                        input_espece.setError("Espece obligatoire");
                    }

                    //Si les champs obligatoire sont pas vide
                    if(!TextUtils.isEmpty(input_name.getText())
                            && !TextUtils.isEmpty(input_sexe.getText())
                            && !TextUtils.isEmpty(input_espece.getText())) {

                        //Je lance mon services en lui passant la callback qui a mon comportement
                        AddEntryService addEntry = new AddEntryService(new AsyncResponce(){
                            @Override
                            public void ComputeResult(Object result) {
                                String res = (String) result;
                                if(res.startsWith("20")){
                                    Toast.makeText(AddEntryActivity.this, "Ajouté avec succes", Toast.LENGTH_LONG).show();
                                }
                                else{
                                    Toast.makeText(AddEntryActivity.this, "Erreur", Toast.LENGTH_LONG).show();
                                }

                                //je vide les champs apres avoir ajouté mon entrée
                                input_name.setText(null);
                                input_sexe.setText(null);
                                input_espece.setText(null);
                                input_desc.setText(null);
                            }
                        });
                        //J'execute mon ajout d'entré
                        addEntry.execute(input_name.getText().toString(), input_sexe.getText().toString(), input_espece.getText().toString(), input_desc.getText().toString());
                    }
                    break;
                case R.id.reset_btn_entry:
                    //Si bouton vider je vide
                    input_name.setText(null);
                    input_sexe.setText(null);
                    input_espece.setText(null);
                    input_desc.setText(null);
                default:
                    break;
            }
        }
    };
}

