package com.ynov.bsc.Activies;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.brice.messagemanager.R;

public class MenuActivity extends AppCompatActivity {

    Button listEntry;
    Button editEntry;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        listEntry = findViewById(R.id.btn_listentry);
        editEntry = findViewById(R.id.btn_addentry);

        listEntry.setOnClickListener(genericOnClickListener);
        editEntry.setOnClickListener(genericOnClickListener);
    }

    View.OnClickListener genericOnClickListener = new View.OnClickListener(){
        @Override
        public void onClick(View v) {
            switch (v.getId()){
                case R.id.btn_listentry:
                    // On redirige vers la liste des entrées
                    Intent toListEntry = new Intent(MenuActivity.this, ListEntryActivity.class);
                    startActivity(toListEntry);
                    break;
                case R.id.btn_addentry:
                    // On redirige vers l'ajout d'entrée
                    Intent toAddEntry = new Intent(MenuActivity.this, AddEntryActivity.class);
                    startActivity(toAddEntry);
                    break;
                default:
                    break;
            }
        }
    };
}
